$(document).ready(function() {
    var dt = new Date();
    let dh = new Date();

    function ajaxDate(date) {
        let year = date.getFullYear(),
            month = date.getMonth() + 1,
            days = date.getDate();
        days = days < 10 ? '0' + days : days;
        month = month < 10 ? '0' + month : month;
        let strTime = year + "-" + month + "-" + days;
        return strTime;
    }

    function renderDate() {
        dt.setDate(7);
        var day = dt.getDay();
        var today = new Date();
        var endDate = new Date(
            dt.getFullYear(),
            dt.getMonth() + 1,
            0
        ).getDate();
        var prevDate = new Date(
            dt.getFullYear(),
            dt.getMonth(),
            0
        ).getDate();
        const lastDayIndex = new Date(
            dt.getFullYear(),
            dt.getMonth() + 1, 0
        ).getDay();
        const nextDays = 7 - lastDayIndex - 1;
        var months = [
            "Январь",
            "Февраль",
            "Март",
            "Апрель",
            "Май",
            "Июнь",
            "Июль",
            "Август",
            "Сентябрь",
            "Октябрь",
            "Ноябрь",
            "Декабрь"
        ];
        var result = [];
        months.forEach(element => {
            let form = element;
            if (form != 'Март' && form != 'Август') {
                result.push(form.replace(/.$/, 'я'));
            } else {
                result.push(form + 'а');
            }
        });
        $("#month").html(months[dt.getMonth()]);
        $("#date_str").html(dt.getFullYear());

        var cells = "";
        for (let x = day; x > 0; x--) {
            cells += `<div data-month="" class='prev_date'>${(prevDate - x + 1)}</div>`;
        }
        for (let i = 1; i <= endDate; i++) {
            if (i == today.getDate() && dt.getMonth() == today.getMonth()) {
                cells += `<div class='today'>${i}</div>`;
            } else {
                if (i < new Date().getDate()) {
                    cells += `<div class="lastDay">${i}</div>`;
                } else if (i >= new Date().getDate()) {
                    cells += `<div>${i}</div>`;

                }
            }

        }
        let weeks = ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", ];

        function DateFormat(date, e) {
            let days = date.getDate(),
                year = date.getFullYear(),
                month = result[date.getMonth()],
                hours = date.getHours(),
                week = weeks[date.getDay()],
                time = date.getTime(),
                minutes = date.getMinutes();
            minutes = minutes < 10 ? '0' + minutes : minutes;
            let strTime = days + " " + month + " " + " " + year + " г.";
            return strTime;
        }


        $(".close").click(function() {
            $(".form-hide").slideUp(1000);

        });
        let empty = "";
        $(".days").html(cells);
        let click = $(".days div").click(function() {
            let active = $(".days div").removeClass("active").eq($(this).index()).addClass("active");
            $(".focus").addClass("scale");
            $(".times").fadeToggle(500);
            $(".times").fadeIn(900);
            dh.setFullYear(dt.getFullYear());
            dh.setMonth(dt.getMonth());
            dh.setDate($(this).text());;
            let value = $(".days div").text();
            if (active) {
                $.ajax({
                    type: 'POST',
                    url: 'https://vtiger.crm.kg/online/',
                    data: {
                        freetime: true,
                        start: ajaxDate(dh),
                        end: ajaxDate(dh)
                    },
                    success: function(msg) {
                        let y = "";
                        var parsed = JSON.parse(msg);
                        for (let i = 0; i < parsed.length; i++) {
                            let result = parsed[i];
                            let time = result.split(' ')[1].substr(0, 5);
                            y += `<div class="time">${time}
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                            </div>`;
                            $(".times").html(y);
                            $(".time").click(function() {
                                var setTime = $(this).text();
                                var kainos = setTime + ',' + DateFormat(dh);
                                $("#select-1").val(setTime);
                                $("#select-2").val(DateFormat(dh));
                                let select = $("#select-1").val().trim(),
                                    select1 = $("#select-2").val().trim();
                                $("#time").val(select1 + ' ' + '' + 'в' + ' ' + select);
                                console.log($("#time").val());

                                $(".form-hide").fadeIn(800);
                            });
                        }
                    }
                });
            } else {
                alert("23");
            }
            $(".close").bind("click", function() {
                $("input[type=text], textarea").val("");
            });

            $(".close-time-modal").click(function() {
                $(".setTime ").removeClass("scale");
            });

        });

        function AddMinutesToDate(date, minutes) {
            return new Date(date.getTime() + minutes * 60000);
        }

        +

        function SDateFormat(date, e) {
            let days = date.getDate(),
                year = date.getFullYear(),
                month = date.getMonth(),
                hours = date.getHours(),
                minutes = date.getMinutes();
            minutes = minutes < 10 ? '0' + minutes : minutes;
            let strTime = hours + ':' + minutes;
            return strTime;
        }
        if (new Date().getMonth() == dt.getMonth()) {
            $(".lastDay").css("color", "#a3a5aa8e");
        } else {
            $(".lastDay").css("color", "#000");
        }
    }

    renderDate();
    let none = function() {
        $(".prev").click(function() {
            if (new Date().getFullYear() < dt.getFullYear() || new Date().getMonth() < dt.getMonth()) {
                dt.setMonth(dt.getMonth() - 1);
            }
            renderDate();
            if (new Date().getMonth() != dt.getMonth() || new Date().getFullYear() != dt.getFullYear()) {}
            if (new Date().getFullYear() < dt.getFullYear() || new Date().getMonth() < dt.getMonth()) {
                $(".lastDay").css("pointer-events", "visible");
            }
        });
        $(".next").click(function() {
            dt.setMonth(dt.getMonth() + 1);
            renderDate();
            if (new Date().getMonth() < dt.getMonth()) {
                $(".lastDay").css("pointer-events", "visible");
            }
            if (new Date().getFullYear() > dt.getFullYear()) {
                $(".days div").css("pointer-events", "none");
            } else if (new Date().getFullYear() < dt.getFullYear()) {
                $(".lastDay").css("pointer-events", "visible");
            }
        });

    };
    none();
    $(".form-hide").hide();
    $("#success").hide();
    $(".location").hide();
    $("#online").click(function() {
        if ($("#online").prop("checked") == true) {
            $(".location").hide(500);
        }
    });
    $("#ofline").click(function() {
        if ($("#ofline").prop("checked") == true) {
            $(".location").show(500);
        }
    });
    let y = 0;
    $(".form_button").click(function(e) {
        e.preventDefault();
        $("form").submit(formSend())
    });
    $(".error").hide();
    $(".form__input").keyup(function() {
        removeError($(this));
    });
    $(".radio__input").click(function() {
        removeError($(this));
    });


    function formSend() {
        var id = String(window.location.href).split('?id=')[1];
        let form = $("#meet_form");
        let error = formValidate(form);
        if (error === 0) {
            let time = ajaxDate(dh) + ' ' + $("#select-1").val(),
                name = $("#name").val(),
                email = $("#email").val(),
                phone = $("#phone").val(),
                theme = $("#theme").val(),
                location = $('#location').val(),
                meet = $('input[name="meet"]').val(),
                description = $('#description').val();

            $.ajax({
                type: "POST",
                url: "https://vtiger.crm.kg/onlineWidget.php?id=" + id,

                data: {
                    send: true,
                    time: time,
                    name: name,
                    email: email,
                    phone: phone,
                    theme: theme,
                    location: location,
                    description: description
                },
                beforeSend: function() {
                    form.parent().closest('.form-hide').addClass('_sending');
                },
                success: function(response) {
                    console.log(response);
                    var response = JSON.parse(response);
                    if (response.success == true) {
                        $(".error-wrap").fadeOut();
                        $("#person").html(response.contact);
                        $("#meet_time").html(response.request.time);
                        if (!response.request.location == "") {
                            $("#meet_location").html(response.request.location);
                        } else {
                            $("#meet_location").html(response.url);
                        }
                    } else if (response.status == false) {
                        $(".success-wrap").fadeOut();
                        $("#errorMessage").html(response.message);
                    }
                    setTimeout(function() {
                        $(".wrap-form").hide();
                        $("#success").fadeToggle(700);
                    }, 2500);
                }
            });
        } else {}

    }
    input = $("input[name='email']");

    function formValidate() {
        let error = 0;
        let formReq = $("._req");
        let warrning = "Укажите допустимый e-mail";
        let req = "Это обязательное поле";
        Array.prototype.forEach.call(formReq, elm => {
            removeError(elm);
            let errMessage = $(".__req");
            if (elm.classList.contains("_email")) {
                if (elm.value == "") {
                    $(".__Emailreq").text(req);
                    addError(elm);
                    error++;
                } else if (!isEmail(elm.value)) {
                    $(".__Emailreq").text("");
                    $(".__Emailreq").text(warrning);
                    addError(elm);
                }
            } else {
                if (elm.value == "") {
                    errMessage.html(req);
                    addError(elm);
                    error++;
                }
                radioVlidate();
            }

        });
        return error;
    }

    function radioVlidate() {
        let valid = false;
        let checkReq = $("input[name='meet']");
        for (let i = 0; i < checkReq.length; i++) {
            if (checkReq[i].checked) {
                valid = true;
                // break;
            }
        }
        if (valid) {
            removeError(checkReq);
        } else {
            addError(checkReq);
        }
    }

    function addError(input) {
        $(input).parent().closest('.form__item').find(".error").show(500)
    }

    function removeError(input) {
        $(input).parent().closest('.form__item').find(".error").hide();
    }

    function isEmail(email) {
        var EmailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return EmailRegex.test(email);
    }
});
$(document).ready(function() {
    $.mask.definitions['d'] = '[0-9]';
    $("input[name='phone']").mask("+996 ddd dd dd dd");

    $('.gotop').click(function() {
        window.scroll({
            top: 0,
            left: 0,
            behavior: 'smooth'
        });
    });

    function copyToClipboard(element) {
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val($(element).text()).select();
        document.execCommand("copy");
        $temp.remove();
    }

    var addrsField = $('.input_copy .txt');
    addrsField.text(window.location);
    $('.input_copy .icon').click(function() {
        copyToClipboard('.input_copy .txt');
        addrsField.addClass('flashBG')
            .delay('1000').queue(function() {
                addrsField.removeClass('flashBG').dequeue();
            });
    });
    $("input[name='time']").attr('disabled', 'disabled');

});
// var id = String(window.location.href).split('?id=')[1]
// $.ajax({
//     type: "POST",
//     url: "https://vtiger.crm.kg/onlineWidget.php?id=" + id,

//     data: {
//         send: true,
//         time: '2022-02-02 21:00:00',
//         name: 'Лид',
//         email: 'test@mail.ru',
//         phone: '0771226554',
//         theme: 'Первая встреча',
//         location: 'Место',
//         description: 'О том о сём'
//     },
//     success: function(text) {
//         console.log(JSON.parse(text));
//         // var parsed = JSON.parse(text);
//         // alert(parsed);
//         // console.log(parsed);
//     }
// });